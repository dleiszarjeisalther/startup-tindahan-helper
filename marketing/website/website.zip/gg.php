<?php
session_start();

$configFile = __DIR__ . '/download_status.json';
$signupsFile = __DIR__ . '/signups.txt';
$logFile = __DIR__ . '/log.txt';
$cacheFile = __DIR__ . '/api/mediafire_cache.json';

// Default configuration
$defaultConfig = [
    'downloads_enabled' => true,
    'apk_download_url' => 'https://www.mediafire.com/file/g9i9m0xq2pg84b8/tindahan-helper.apk/file',
    'disabled_message' => 'Pansamantalang sarado ang public APK download para sa update. Mangyaring tumawag o mag-text sa 0991 658 9854 para sa direct VIP installation.',
    'contact_number' => '0991 658 9854',
    'updated_at' => date('Y-m-d H:i:s')
];

// Load current configuration
if (file_exists($configFile)) {
    $config = json_decode(file_get_contents($configFile), true) ?: $defaultConfig;
    if (!isset($config['apk_download_url'])) {
        $config['apk_download_url'] = 'https://www.mediafire.com/file/g9i9m0xq2pg84b8/tindahan-helper.apk/file';
    }
} else {
    $config = $defaultConfig;
    file_put_contents($configFile, json_encode($config, JSON_PRETTY_PRINT));
}

// Handle Status Toggle POST
$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        if ($_POST['action'] === 'toggle') {
            $config['downloads_enabled'] = !$config['downloads_enabled'];
            $config['updated_at'] = date('Y-m-d H:i:s');
            file_put_contents($configFile, json_encode($config, JSON_PRETTY_PRINT));
            $message = $config['downloads_enabled'] 
                ? '✅ APK Download is now ENABLED (Maaari nang mag-download ang mga users).' 
                : '⛔ APK Download is now DISABLED (Naka-block na ang download sa website).';
        } elseif ($_POST['action'] === 'update_apk_url') {
            $config['apk_download_url'] = trim($_POST['apk_download_url'] ?? '');
            if (empty($config['apk_download_url'])) {
                $config['apk_download_url'] = 'https://www.mediafire.com/file/g9i9m0xq2pg84b8/tindahan-helper.apk/file';
            }
            $config['updated_at'] = date('Y-m-d H:i:s');
            file_put_contents($configFile, json_encode($config, JSON_PRETTY_PRINT));
            // Invalidate cache when link changes
            if (file_exists($cacheFile)) {
                @unlink($cacheFile);
            }
            $message = '✅ Na-update ang APK Download Source URL!';
        } elseif ($_POST['action'] === 'update_message') {
            $config['disabled_message'] = trim($_POST['disabled_message'] ?? $config['disabled_message']);
            $config['updated_at'] = date('Y-m-d H:i:s');
            file_put_contents($configFile, json_encode($config, JSON_PRETTY_PRINT));
            $message = '✅ Na-update ang advisory message!';
        } elseif ($_POST['action'] === 'clear_leads') {
            file_put_contents($signupsFile, "# STARTUP TINDAHAN HELPER - MGA NAG-SIGN UP\n# Cleared at " . date('Y-m-d H:i:s') . "\n\n");
            $message = '⚠️ Na-clear na ang signups.txt.';
        } elseif ($_POST['action'] === 'clear_logs') {
            file_put_contents($logFile, "# STARTUP TINDAHAN HELPER - ACTION LOGS\n# Cleared at " . date('Y-m-d H:i:s') . "\n\n");
            $message = '⚠️ Na-clear na ang log.txt.';
        } elseif ($_POST['action'] === 'clear_cache') {
            if (file_exists($cacheFile)) {
                @unlink($cacheFile);
            }
            $message = '🔄 Na-clear ang MediaFire resolver cache!';
        }
    }
}

// Read contents
$signupsContent = file_exists($signupsFile) ? file_get_contents($signupsFile) : 'Wala pang nag-sign up.';
$logsContent = file_exists($logFile) ? file_get_contents($logFile) : 'Wala pang laman ang log.txt.';
$hasCachedResolver = file_exists($cacheFile);
$cacheInfo = $hasCachedResolver ? json_decode(file_get_contents($cacheFile), true) : null;
?>
<!DOCTYPE html>
<html lang="tl">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Control Panel - Tindahan Helper</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="icon" type="image/png" href="./assets/images/favicon.png">
</head>
<body class="bg-slate-950 text-slate-100 min-h-screen py-10 px-4">
  <div class="max-w-3xl mx-auto space-y-6">

    <!-- Header -->
    <div class="flex items-center justify-between border-b border-slate-800 pb-5">
      <div class="flex items-center gap-3">
        <img src="./assets/images/logo.png" alt="Logo" class="w-10 h-10 rounded-xl">
        <div>
          <h1 class="text-xl font-bold text-white tracking-tight">Tindahan Helper Admin Control</h1>
          <p class="text-xs text-slate-400">Pamahalaan ang APK Download status at listahan ng sign-ups</p>
        </div>
      </div>
      <a href="./index.html" target="_blank" class="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-200 transition-colors">
        Tingnan ang Website &rarr;
      </a>
    </div>

    <!-- Alert Message -->
    <?php if (!empty($message)): ?>
      <div class="p-4 rounded-xl bg-blue-900/40 border border-blue-500/50 text-blue-200 text-sm font-medium">
        <?= htmlspecialchars($message) ?>
      </div>
    <?php endif; ?>

    <!-- Status Card -->
    <div class="p-6 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl space-y-5">
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <span class="text-xs font-semibold uppercase tracking-wider text-slate-400">Kasalukuyang Status ng APK Download:</span>
          <div class="mt-1 flex items-center gap-3">
            <?php if ($config['downloads_enabled']): ?>
              <span class="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 font-bold text-sm">
                <span class="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping"></span>
                ENABLED (Bukas ang Download)
              </span>
            <?php else: ?>
              <span class="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-red-500/20 text-red-400 border border-red-500/40 font-bold text-sm">
                <span class="w-2.5 h-2.5 rounded-full bg-red-400"></span>
                DISABLED (Naka-block ang Download)
              </span>
            <?php endif; ?>
          </div>
          <p class="text-xs text-slate-500 mt-2">Huling binago: <?= htmlspecialchars($config['updated_at']) ?></p>
        </div>

        <!-- Toggle Form Button -->
        <form method="POST">
          <input type="hidden" name="action" value="toggle">
          <?php if ($config['downloads_enabled']): ?>
            <button type="submit" class="w-full sm:w-auto px-6 py-3 rounded-xl bg-red-600 hover:bg-red-500 text-white font-bold text-sm shadow-lg shadow-red-600/30 transition-all">
              ⛔ I-DISABLE ang APK Download
            </button>
          <?php else: ?>
            <button type="submit" class="w-full sm:w-auto px-6 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-sm shadow-lg shadow-emerald-600/30 transition-all">
              ✅ I-ENABLE ang APK Download
            </button>
          <?php endif; ?>
        </form>
      </div>

      <!-- Contact Info Box -->
      <div class="pt-4 border-t border-slate-800 text-xs text-slate-400 flex flex-wrap items-center justify-between gap-2">
        <span>Admin Helpline / Contact: <strong class="text-white">0991 658 9854</strong></span>
        <span>Kasalukuyang APK Link: <strong class="text-emerald-400 font-mono"><?= htmlspecialchars($config['apk_download_url'] ?? './apk/tindahan-helper.apk') ?></strong></span>
      </div>
    </div>

    <!-- APK Download URL / Cloud Storage Settings -->
    <div class="p-6 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl space-y-4">
      <div class="flex items-center justify-between">
        <div>
          <h2 class="text-base font-bold text-white flex items-center gap-2">
            <span>☁️</span> APK Download Source URL (InfinityFree Alternative)
          </h2>
          <p class="text-xs text-slate-400 mt-1">
            Dahil may <strong>10 MB file limit</strong> ang libreng hosting ng InfinityFree, i-upload ang 133 MB APK sa alinman sa mga sumusunod at ilagay dito ang link:
          </p>
        </div>
      </div>

      <!-- Quick alternatives guide badge -->
      <div class="grid grid-cols-1 sm:grid-cols-3 gap-2.5 text-xs text-slate-300">
        <div class="p-2.5 rounded-xl bg-slate-950/80 border border-slate-800">
          <span class="font-bold text-white block mb-0.5">1. GitHub Releases ⭐</span>
          <span class="text-slate-400">Libre hanggang 2 GB/file. Direct CDN download link na walang ads.</span>
        </div>
        <div class="p-2.5 rounded-xl bg-slate-950/80 border border-slate-800">
          <span class="font-bold text-white block mb-0.5">2. Google Drive</span>
          <span class="text-slate-400">15 GB free space. I-share ang file bilang &quot;Anyone with the link&quot;.</span>
        </div>
        <div class="p-2.5 rounded-xl bg-slate-950/80 border border-slate-800">
          <span class="font-bold text-white block mb-0.5">3. Dropbox / MediaFire</span>
          <span class="text-slate-400">Palitan ang ?dl=0 ng ?dl=1 sa Dropbox para sa direct download.</span>
        </div>
      </div>

      <form method="POST" class="space-y-3 pt-2">
        <input type="hidden" name="action" value="update_apk_url">
        <div>
          <label class="block text-xs font-semibold text-slate-300 mb-1">Direct APK Download Link o Cloud URL:</label>
          <input type="text" name="apk_download_url" value="<?= htmlspecialchars($config['apk_download_url'] ?? './apk/tindahan-helper.apk') ?>" placeholder="Halimbawa: https://github.com/username/repo/releases/download/v1.0.0/tindahan-helper.apk" class="w-full p-3 rounded-xl bg-slate-950 border border-slate-700 text-sm text-white focus:outline-none focus:border-blue-500 font-mono">
        </div>
        <div class="flex flex-wrap items-center gap-3">
          <button type="submit" class="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-xs font-semibold text-white transition-all shadow-md">
            I-save ang APK Link
          </button>
          <span class="text-xs text-slate-500">Kasalukuyang ginagamit ng website: <code class="text-emerald-400"><?= htmlspecialchars($config['apk_download_url'] ?? './apk/tindahan-helper.apk') ?></code></span>
        </div>
      </form>
    </div>

    <!-- Disabled Advisory Message Customizer -->
    <div class="p-6 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl space-y-4">
      <h2 class="text-base font-bold text-white">Mensahe kapag Naka-Disable ang Download</h2>
      <p class="text-xs text-slate-400">
        Ito ang mensaheng lalabas sa modal o alert kapag sinubukan ng user na mag-download habang naka-disable:
      </p>
      <form method="POST" class="space-y-3">
        <input type="hidden" name="action" value="update_message">
        <textarea name="disabled_message" rows="3" class="w-full p-3 rounded-xl bg-slate-950 border border-slate-700 text-sm text-white focus:outline-none focus:border-blue-500"><?= htmlspecialchars($config['disabled_message']) ?></textarea>
        <button type="submit" class="px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-500 text-xs font-semibold text-white transition-all">
          I-save ang Mensahe
        </button>
      </form>
    </div>

    <!-- Sign-ups / Leads Viewer -->
    <div class="p-6 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl space-y-4">
      <div class="flex items-center justify-between">
        <div>
          <h2 class="text-base font-bold text-white">Talaan ng mga Nag-Sign Up (signups.txt)</h2>
          <p class="text-xs text-slate-400">Lahat ng detalye mula sa website form</p>
        </div>
        <a href="./signups.txt" download class="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-blue-400 transition-colors">
          I-download ang signups.txt
        </a>
      </div>

      <pre class="w-full max-h-80 overflow-y-auto p-4 rounded-xl bg-slate-950 border border-slate-800 font-mono text-xs text-emerald-400 whitespace-pre-wrap select-all"><?= htmlspecialchars($signupsContent) ?></pre>

      <form method="POST" onsubmit="return confirm('Sigurado ka bang gusto mong burahin ang laman ng signups.txt?');">
        <input type="hidden" name="action" value="clear_leads">
        <button type="submit" class="text-xs text-red-400 hover:text-red-300 underline">
          I-clear ang signups.txt listahan
        </button>
      </form>
    </div>

    <!-- Diagnostic Action Logs Viewer (log.txt) -->
    <div class="p-6 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl space-y-4">
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 class="text-base font-bold text-white flex items-center gap-2">
            <span>🔍</span> Diagnostic Action Logs (<span class="font-mono text-cyan-400 text-xs">log.txt</span>)
          </h2>
          <p class="text-xs text-slate-400">
            Dito nakikita ang eksaktong nangyayari sa background kapag nag-download ang user (cURL status, MediaFire parsing, at fallback reasons sa InfinityFree).
          </p>
        </div>
        <div class="flex items-center gap-2">
          <form method="POST" class="inline">
            <input type="hidden" name="action" value="clear_cache">
            <button type="submit" title="I-clear ang cached direct link para subukan uli ang live resolver" class="px-3 py-1.5 rounded-lg bg-amber-600/30 hover:bg-amber-600/50 text-amber-300 border border-amber-500/40 text-xs font-semibold transition-colors">
              🔄 Clear Cache
            </button>
          </form>
          <a href="./log.txt" download class="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-cyan-400 transition-colors">
            I-download ang log.txt
          </a>
        </div>
      </div>

      <!-- Cache status badge if present -->
      <?php if ($hasCachedResolver && isset($cacheInfo['direct_url'])): ?>
        <div class="p-3 rounded-xl bg-emerald-950/40 border border-emerald-500/30 text-xs text-emerald-300 flex items-center justify-between gap-2">
          <div class="truncate">
            <span class="font-bold">⚡ Active Cached Direct Link:</span>
            <code class="font-mono text-emerald-400 ml-1"><?= htmlspecialchars(substr($cacheInfo['direct_url'], 0, 75)) ?>...</code>
          </div>
          <span class="shrink-0 text-slate-400">Expires: <?= date('H:i:s', $cacheInfo['expires_at']) ?></span>
        </div>
      <?php endif; ?>

      <pre class="w-full max-h-96 overflow-y-auto p-4 rounded-xl bg-slate-950 border border-slate-800 font-mono text-xs text-cyan-300 whitespace-pre-wrap select-all"><?= htmlspecialchars($logsContent) ?></pre>

      <form method="POST" onsubmit="return confirm('Sigurado ka bang gusto mong burahin ang laman ng log.txt?');">
        <input type="hidden" name="action" value="clear_logs">
        <button type="submit" class="text-xs text-red-400 hover:text-red-300 underline">
          I-clear ang log.txt listahan
        </button>
      </form>
    </div>

  </div>
</body>
</html>
